# ============================
# AI Lab 9 - Data Exploration
# ============================

import pandas as pd
from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas
from reportlab.lib.units import mm
from datetime import datetime

# ---- Step 1: Load Dataset ----
file_path = "data.csv"  # Make sure this file is in the same folder
df = pd.read_csv(file_path)

# ---- Step 2: Explore Data ----
print("\n--- TOP 5 ROWS ---")
print(df.head())

print("\n--- BOTTOM 5 ROWS ---")
print(df.tail())

print("\n--- DATASET SHAPE ---")
print(f"Rows: {df.shape[0]}, Columns: {df.shape[1]}")

print("\n--- NULL VALUES PER COLUMN ---")
print(df.isnull().sum())

# ---- Step 3: Handle Missing Data ----
numeric_cols = df.select_dtypes(include=["number"]).columns
filled_mean = df.copy()
filled_mean[numeric_cols] = filled_mean[numeric_cols].fillna(filled_mean[numeric_cols].mean())

filled_median = df.copy()
filled_median[numeric_cols] = filled_median[numeric_cols].fillna(filled_median[numeric_cols].median())

filled_mode = df.copy()
modes = filled_mode.mode().iloc[0]
filled_mode = filled_mode.fillna(modes)

print("\n--- SAMPLE AFTER FILLING NULLS (USING MODE) ---")
print(filled_mode.head())

print("\n--- DATA TYPES ---")
print(df.dtypes)

# ---- Step 4: Save PDF Report ----
output_pdf = "AI_Lab9_Report.pdf"
report_title = "AI Lab 9 - Data Exploration Report"
generated_on = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

def write_block(c, title, text, x, y, width, height, margin):
    c.setFont("Helvetica-Bold", 11)
    c.drawString(x, y, title)
    c.setFont("Helvetica", 9)
    text_lines = text.splitlines()
    cur_y = y - 12
    for line in text_lines:
        if cur_y < margin + 20:
            c.showPage()
            cur_y = height - margin
            c.setFont("Helvetica", 9)
        max_chars = 95
        while len(line) > max_chars:
            c.drawString(x, cur_y, line[:max_chars])
            line = line[max_chars:]
            cur_y -= 10
            if cur_y < margin + 20:
                c.showPage()
                cur_y = height - margin
                c.setFont("Helvetica", 9)
        c.drawString(x, cur_y, line)
        cur_y -= 10
    return cur_y

# ---- Generate PDF ----
c = canvas.Canvas(output_pdf, pagesize=A4)
width, height = A4
margin = 15 * mm
x = margin
y = height - margin

# Title
c.setFont("Helvetica-Bold", 16)
c.drawString(x, y, report_title)
c.setFont("Helvetica", 9)
c.drawString(x, y - 18, f"Generated on: {generated_on}")
y -= 36

# Add sections
y = write_block(c, "1) Top 5 rows:", df.head().to_string(), x, y, width, height, margin)
y -= 6
y = write_block(c, "2) Bottom 5 rows:", df.tail().to_string(), x, y, width, height, margin)
y -= 6
y = write_block(c, "3) Shape (Rows, Columns):", f"{df.shape}", x, y, width, height, margin)
y -= 6
y = write_block(c, "4) Null values per column:", df.isnull().sum().to_string(), x, y, width, height, margin)
y -= 6
y = write_block(c, "5) Example (nulls filled using mode):", filled_mode.head().to_string(), x, y, width, height, margin)
y -= 6
y = write_block(c, "6) Data types of each column:", df.dtypes.to_string(), x, y, width, height, margin)

c.showPage()
c.save()

